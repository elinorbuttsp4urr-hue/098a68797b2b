// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("linux mips64"); }
int main(){
  announce();
  return lionss_run_workload("linux-mips64");
}
