// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("feature flags matrix"); }
int main(){
  announce();
  return lionss_run_workload("feature-flags-matrix");
}
