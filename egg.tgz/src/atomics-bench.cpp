// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("atomics bench\n", stdout);
  return lionss_run_workload("atomics-bench");
}
